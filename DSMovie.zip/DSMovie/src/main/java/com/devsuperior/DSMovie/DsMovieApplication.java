package com.devsuperior.DSMovie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsMovieApplication {

	public static void main(String[] args) {
		SpringApplication.run(DsMovieApplication.class, args);
	}

}
