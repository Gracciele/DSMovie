package com.devsuperior.DSMovie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsMovieApplicationTests {

	@Test
	void contextLoads() {
	}

}
